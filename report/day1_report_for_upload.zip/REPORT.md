# BÁO CÁO BÀI THỰC HÀNH NGÀY 1
**Đọc prediction YOLO11 để hiểu định dạng nhãn (Ground Truth)**

---

## 1. Thông tin chung & Môi trường thực nghiệm

### Thông tin sinh viên / Học viên
- **Ngày chạy:** 06/11/2026
- **Họ và tên:** Trương Duy Anh
- **Repository GitHub:** [](https://github.com/duyanh211105/K5-L2-DAY01-Truong-Duy-Anh---2A202603027-Data-Overview-AI-ML-DL) 

### Thông số môi trường (được ghi nhận từ Colab Run)
- **Python Version:** `3.13.16`
- **PyTorch Version:** `2.11.0+cu130`
- **Ultralytics Version:** `8.4.145` (đã kiểm tra cố định phiên bản)
- **Phần cứng (Device):** `cuda` (GPU)
- **Checkpoints sử dụng:**
  - Classification: `yolo11n-cls.pt` (SHA256: `c62d41bf9625...`)
  - Detection: `yolo11n.pt` (SHA256: `0ebbc80d4a76...`)
  - Segmentation: `yolo11n-seg.pt` (SHA256: `55ed65c56c91...`)

---

## 2. Mục tiêu & Luồng công việc (Workflow)

### Mục tiêu bài lab
- Quan sát các **prediction** (dự đoán) của mô hình YOLO11 (Task: Classification, Detection, Segmentation) trên các ảnh COCO công khai.
- Từ prediction của mô hình, suy ngược lại **định dạng ground truth (GT)** mà annotator (người gán nhãn) cần tạo trong thực tế sản xuất.
- Phân biệt rõ ràng: Prediction không phải là nhãn chuẩn; Model score (confidence) không thể hiện chất lượng của nhãn gán.

### Vòng đời dữ liệu trong Production vs. Bài Lab
- **Lab hôm nay (Quan sát & Đối chiếu):**
  $$\text{Ảnh công khai} \rightarrow \text{Checkpoint} \rightarrow \text{Prediction} \rightarrow \text{Đối chiếu Guideline} \rightarrow \text{Hiểu định dạng GT}$$
- **Vòng đời Production thực tế:**
  $$\text{Ảnh thô} \rightarrow \text{Guideline} \rightarrow \text{Ground Truth (Annotator)} \rightarrow \text{Huấn luyện Model} \rightarrow \text{Prediction} \rightarrow \text{QC / Rework}$$

---

## 3. Phân tích kết quả thực nghiệm theo từng Task

### 3.1. Task 1: Image Classification (Phân loại ảnh)
- **Dữ liệu / Checkpoint:** `yolo11n-cls.pt`
- **Định dạng Output của Prediction:**
  - Trả về danh sách xác suất (confidence score) tương ứng với các lớp (classes) trong Taxonomy (COCO/ImageNet).
  - Chọn lớp có xác suất cao nhất làm nhãn dự đoán cho toàn bộ bức ảnh.
- **Suy luận Định dạng Ground Truth (GT):**
  - **Định dạng file nhãn:** Nhãn mức ảnh (Image-level label). Thường lưu dưới dạng file text, JSON hoặc cấu trúc thư mục chứa tệp (ví dụ: `labels.txt` hoặc tên thư mục chứa lớp).
  - **Cấu trúc dữ liệu:** Một ID lớp (Class ID) hoặc tên lớp (Class Name) duy nhất cho mỗi ảnh. Không có thông tin tọa độ (Bounding Box).

### 3.2. Task 2: Object Detection (Phát hiện vật thể)
- **Dữ liệu / Checkpoint:** `yolo11n.pt`
- **Dữ liệu mẫu kiểm thử:** `traffic` (COCO ID: 210273), `kitchen` (COCO ID: 397133), `dining` (COCO ID: 166918).
- **Định dạng Output của Prediction:**
  - Danh sách các bounding box kèm theo `class_id` và `confidence_score`.
  - Tọa độ khung chữ nhật bao quanh vật thể.
- **Suy luận Định dạng Ground Truth (GT):**
  - **Định dạng chuẩn (YOLO format):** Mỗi ảnh có 1 file `.txt` tương ứng.
  - **Cấu trúc dòng nhãn (Normalized coordinates):**
    $$\langle\text{class\_id}\rangle \quad \langle x_{\text{center}}\rangle \quad \langle y_{\text{center}}\rangle \quad \langle\text{width}\rangle \quad \langle\text{height}\rangle$$
    *(Tất cả tọa độ $x, y, w, h$ đều được chuẩn hóa về khoảng $[0, 1]$ dựa trên kích thước ảnh)*.
  - **Lưu ý:** Ground Truth **không** chứa trường `confidence_score` như Prediction.

### 3.3. Task 3: Instance Segmentation (Phân đoạn vật thể)
- **Dữ liệu / Checkpoint:** `yolo11n-seg.pt`
- **Định dạng Output của Prediction:**
  - Tọa độ Bounding Box + Class ID + Confidence Score + Mặt nạ phân đoạn (Polygon mask / Binary mask) phủ lên chính xác ranh giới của vật thể.
- **Suy luận Định dạng Ground Truth (GT):**
  - **Định dạng chuẩn (YOLO Polygon format):** File `.txt` cho mỗi ảnh.
  - **Cấu trúc dòng nhãn:**
    $$\langle\text{class\_id}\rangle \quad x_1 \quad y_1 \quad x_2 \quad y_2 \quad \dots \quad x_n \quad y_n$$
    *(Danh sách tọa độ đỉnh đa giác (Polygon) xoay quanh viền vật thể, chuẩn hóa trong khoảng $[0, 1]$)*.

---

## 4. Quan sát Edge Cases & Quy tắc xử lý (Escalation)

Trong quá trình đối chiếu giữa Prediction của YOLO11 và ảnh thực tế, có một số trường hợp khó quyết định nhãn (Edge Cases):

1. **Vật thể bị che khuất (Occlusion) hoặc bị cắt viền (Truncation):**
   - **Hiện tượng:** Model có thể bỏ sót vật thể chỉ lộ một phần nhỏ hoặc dự đoán sai bounding box.
   - **Quy tắc gán nhãn GT:** Người gán nhãn cần vẽ bọc toàn bộ phần nhìn thấy được (hoặc theo quy định cụ thể của Guideline dự án).

2. **Vật thể quá nhỏ hoặc mờ ở hậu cảnh:**
   - **Hiện tượng:** Model không phát hiện được (False Negative).
   - **Quy tắc gán nhãn GT:** Kiểm tra xem Guideline có quy định ngưỡng kích thước tối thiểu (ví dụ: $> 10 \times 10$ pixels) để gán nhãn hay không.

3. **Quy trình Escalation:**
   - Khi gặp trường hợp mơ hồ, annotator **không tự ý bịa nhãn**.
   - **Các bước:** Ghi nhận case khó $\rightarrow$ Báo cáo/Hỏi Lab Coach/QC Lead $\rightarrow$ Cập nhật vào tài liệu Guideline để thống nhất tiêu chuẩn gán nhãn.

---

## 5. Kết luận & Bài học rút ra

1. **Phân biệt Prediction vs Ground Truth:** Prediction là đầu ra mang tính xác suất của mô hình, phụ thuộc vào Threshold và Checkpoint. Ground Truth là "chân lý" chuẩn mực được con người tạo ra dựa trên Guideline cụ thể.
2. **Hiểu rõ định dạng nhãn theo Task:**
   - Phân loại (Classification): Lớp duy nhất.
   - Phát hiện (Detection): Class ID + Tọa độ khung bọc ($x_{\text{center}}, y_{\text{center}}, w, h$).
   - Phân đoạn (Segmentation): Class ID + Chuỗi tọa độ đỉnh đa giác ($x_1, y_1, x_2, y_2, \dots$).
3. **Tầm quan trọng của Data Quality:** Mô hình tốt bắt đầu từ dữ liệu chuẩn. Việc hiểu rõ output của model giúp xây dựng được Data Pipeline và Annotation Guideline chính xác cho vòng đời phát triển AI/ML/DL trong thực tế sản xuất.

---

